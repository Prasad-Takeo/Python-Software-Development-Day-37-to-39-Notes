import datetime

from django.db import models
from django.utils import timezone

import datetime
"""
Polls Models
"""

class Question(models.Model):
    questions = models.CharField(max_length=200)
    pub_date = models.DateTimeField('date_published',blank=True,null=True)
    created_at = models.DateTimeField('created_at',auto_now_add=True)

    def __str__(self):
        return self.questions

    def was_published_recently(self):
        return self.pub_date >=  timezone.now() - datetime.timedelta(days=1)

    ## if the pubication date is greater than or equal to (today - 1 day)

    #is question long return True if the len is greater than 100
    def is_question_long(self):
        return len(self.questions) > 100

class Choice(models.Model):
    question = models.ForeignKey(Question, on_delete=models.CASCADE, related_name="answers")
    choice_text = models.CharField(max_length=200)
    votes = models.PositiveIntegerField()

    def __str__(self):
        return self.choice_text

##FWD for each choice, there is a question
##REV for the question, what are the choices

